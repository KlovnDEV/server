fx_version "cerulean"
game "gta5"

name "Interactive Scenes"
description "Interactive Scene Creator for FiveM"
author "NeroHiro"

client_scripts {
    "client.lua",
    "functions.lua"
}

server_script "server.lua"